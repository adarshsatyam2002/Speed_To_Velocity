public class Speed_To_Velocity_Convertor {
    public static void main(String[] args) {

        int speed;
        speed = 90;

        double velocity = (double) speed*5/18;
        System.out.println(speed + "km/h to " + velocity + " m/s");
    }
}
